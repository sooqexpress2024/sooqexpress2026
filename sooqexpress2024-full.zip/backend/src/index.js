const express = require('express');
const cors = require('cors');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { PrismaClient } = require('@prisma/client');
const multer = require('multer');
const upload = multer({ dest: 'uploads/' });
const prisma = new PrismaClient();

const app = express();
app.use(cors());
app.use(express.json());

const JWT_SECRET = process.env.JWT_SECRET || 'change_this_in_prod';
const ADMIN_KEY = process.env.ADMIN_KEY || 'admin_key';

// Public - products
app.get('/api/products', async (req, res) => {
  const products = await prisma.product.findMany({ orderBy: { createdAt: 'desc' } });
  res.json(products);
});

app.get('/api/products/:id', async (req, res) => {
  const p = await prisma.product.findUnique({ where: { id: Number(req.params.id) } });
  if(!p) return res.status(404).json({ error: 'Not found' });
  res.json(p);
});

// Register / Login
app.post('/api/auth/register', async (req, res) => {
  const { email, password, name } = req.body;
  const hash = await bcrypt.hash(password, 10);
  try {
    const user = await prisma.user.create({ data: { email, password: hash, name } });
    res.json({ id: user.id, email: user.email });
  } catch(e) {
    res.status(400).json({ error: 'Email exists or invalid' });
  }
});

app.post('/api/auth/login', async (req, res) => {
  const { email, password } = req.body;
  const user = await prisma.user.findUnique({ where: { email } });
  if(!user) return res.status(401).json({ error: 'Invalid' });
  const ok = await bcrypt.compare(password, user.password);
  if(!ok) return res.status(401).json({ error: 'Invalid' });
  const token = jwt.sign({ id: user.id, email: user.email, role: user.role }, JWT_SECRET, { expiresIn: '7d' });
  res.json({ token });
});

// Place order (simple)
app.post('/api/orders', async (req, res) => {
  const { items, total, customerEmail } = req.body;
  if(!items || !Array.isArray(items) || items.length===0) return res.status(400).json({ error: 'No items' });
  const order = await prisma.order.create({ data: { itemsJson: JSON.stringify(items), total: Number(total) } });
  res.json({ success: true, order });
});

// Admin add product (protected by ADMIN_KEY header)
app.post('/api/admin/products', upload.single('image'), async (req, res) => {
  const key = req.headers['x-admin-key'] || req.query.key;
  if(key !== ADMIN_KEY) return res.status(401).json({ error: 'Unauthorized' });
  const { title, description, price, stock, image } = req.body;
  const prod = await prisma.product.create({ data: { title, description, price: Number(price), stock: Number(stock), image } });
  res.json(prod);
});

app.get('/', (req, res) => res.json({ status: 'ok' }));

const port = process.env.PORT || 5000;
app.listen(port, ()=> console.log('Backend listening on', port));
