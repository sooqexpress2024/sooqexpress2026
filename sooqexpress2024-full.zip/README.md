SooqExpress2024 - Amazon-like store (starter)

Folders:
- backend/  => API (Prisma + PostgreSQL)
- frontend/ => Next.js frontend

Quick start (local, needs Docker Compose or Postgres):
- Create a PostgreSQL database and set DATABASE_URL in backend/.env
- cd backend && npm install
- npx prisma generate
- npx prisma migrate dev --name init  (for development)
- cd ../frontend && npm install && npm run dev

Deploy notes:
- Create a Postgres DB on Render and set DATABASE_URL there
- Deploy backend to Render as Web Service (connect GitHub or upload zip)
- Set env vars: DATABASE_URL, JWT_SECRET, ADMIN_KEY
- Deploy frontend as Web Service or Static Site; set NEXT_PUBLIC_API_BASE to backend URL

