import axios from 'axios';
import Link from 'next/link';
const API_BASE = process.env.NEXT_PUBLIC_API_BASE || 'http://localhost:5000';

export default function Home({ products }){
  return (
    <div>
      <header style={{background:'#111', color:'#fff', padding:16}}><h1>سوق اكسبرس</h1></header>
      <main style={{display:'flex', gap:20, padding:20}}>
        <section style={{flex:2}}>
          <h2>المنتجات</h2>
          <div style={{display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(220px,1fr))', gap:12}}>
            {products.map(p=>(
              <div key={p.id} style={{border:'1px solid #ddd', padding:12}}>
                <img src={(p.image? (process.env.NEXT_PUBLIC_API_BASE || API_BASE)+p.image : '/noimg.png')} style={{width:'100%',height:140,objectFit:'cover'}}/>
                <h3>{p.title}</h3>
                <p>{p.description}</p>
                <div>{p.price} $</div>
                <Link href={'/product/' + p.id}><a>عرض</a></Link>
              </div>
            ))}
          </div>
        </section>
        <aside style={{width:320}}>
          <h3>عربة التسوق</h3>
          <div>تعمل بالـ localStorage في النسخة البسيطة</div>
        </aside>
      </main>
    </div>
  )
}

export async function getServerSideProps(){
  try{
    const res = await axios.get((process.env.NEXT_PUBLIC_API_BASE || 'http://localhost:5000') + '/api/products');
    return { props: { products: res.data } };
  }catch(e){
    return { props: { products: [] } };
  }
}
