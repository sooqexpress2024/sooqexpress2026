import axios from 'axios';
const API_BASE = process.env.NEXT_PUBLIC_API_BASE || 'http://localhost:5000';
export default function Product({ product }){
  if(!product) return <div>لا يوجد المنتج</div>
  return (
    <div style={{padding:20}}>
      <h2>{product.title}</h2>
      <img src={(product.image? (process.env.NEXT_PUBLIC_API_BASE || API_BASE)+product.image : '/noimg.png')} style={{width:320}} />
      <p>{product.description}</p>
      <div>السعر: {product.price} $</div>
    </div>
  )
}
export async function getServerSideProps({ params }){
  try{
    const res = await axios.get((process.env.NEXT_PUBLIC_API_BASE || 'http://localhost:5000') + '/api/products/' + params.id);
    return { props: { product: res.data } };
  }catch(e){ return { props: { product: null } }; }
}
